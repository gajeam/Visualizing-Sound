Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - Carlos_Vaquero ( https://freesound.org/people/Carlos_Vaquero/ )

You can find this pack online at: https://freesound.org/people/Carlos_Vaquero/packs/9540/

License details
---------------

Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 154050__carlos-vaquero__psalterium-b-4-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154050/
    * license: Attribution Noncommercial
  * 154049__carlos-vaquero__psalterium-a-4-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154049/
    * license: Attribution Noncommercial
  * 154048__carlos-vaquero__psalterium-a-4-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154048/
    * license: Attribution Noncommercial
  * 154047__carlos-vaquero__psalterium-g-4-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154047/
    * license: Attribution Noncommercial
  * 154046__carlos-vaquero__psalterium-f-4-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154046/
    * license: Attribution Noncommercial
  * 154045__carlos-vaquero__psalterium-e-4-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154045/
    * license: Attribution Noncommercial
  * 154044__carlos-vaquero__psalterium-d-4-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154044/
    * license: Attribution Noncommercial
  * 154043__carlos-vaquero__psalterium-c-4-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154043/
    * license: Attribution Noncommercial
  * 154042__carlos-vaquero__psalterium-b-3-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154042/
    * license: Attribution Noncommercial
  * 154041__carlos-vaquero__psalterium-a-3-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154041/
    * license: Attribution Noncommercial
  * 154040__carlos-vaquero__psalterium-a-3-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154040/
    * license: Attribution Noncommercial
  * 154039__carlos-vaquero__psalterium-f-3-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154039/
    * license: Attribution Noncommercial
  * 154038__carlos-vaquero__psalterium-e-3-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154038/
    * license: Attribution Noncommercial
  * 154037__carlos-vaquero__psalterium-d-3-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154037/
    * license: Attribution Noncommercial
  * 154036__carlos-vaquero__psalterium-c-3-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154036/
    * license: Attribution Noncommercial
  * 154035__carlos-vaquero__psalterium-b-2-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154035/
    * license: Attribution Noncommercial
  * 154034__carlos-vaquero__psalterium-a-2-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154034/
    * license: Attribution Noncommercial
  * 154033__carlos-vaquero__psalterium-a-2-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154033/
    * license: Attribution Noncommercial
  * 154032__carlos-vaquero__psalterium-g-2-plucked-non-vibrato.wav
    * url: https://freesound.org/s/154032/
    * license: Attribution Noncommercial


